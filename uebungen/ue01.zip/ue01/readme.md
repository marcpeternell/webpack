# To-Do

1. Installiere Webpack mit Hilfe von node

2. Bundle die src/app.js mit Hilfe von Webpack. Binde die generierte Datei in der index.html ein, öffne die Seite im Browser und überprüfe die Konsole ob die Umwandlung funktioniert hat.

# Hinweis 
lodash muss mit npm installiert werden.