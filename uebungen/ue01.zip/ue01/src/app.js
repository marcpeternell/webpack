import _ from 'lodash';
console.log(_.upperCase('Hello Webpack'));
