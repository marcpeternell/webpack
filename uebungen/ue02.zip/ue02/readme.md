# To-Dos

1. Installiere die node_modules

2. Erstelle und configuriere die Webpack Config Datei

3. Bundle die src/app.js mit Webpack

4. Öffne die index.html im Browser und untersuche die Konsole