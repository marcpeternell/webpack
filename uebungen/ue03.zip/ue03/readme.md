# To-Dos

1. Füge den webpack Befehl der package.json Datei hinzu und führe in aus. 