# To-Do

1. bundle die Datei src/app.js und suche in dem outpuf File nach der Funktion square()

2. ersetze in der webpack.config.js den mode durch "production" und suche nach sqare erneut