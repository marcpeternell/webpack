import {cube} from './maths.js';
console.log(cube(6)); 
