# To-Do

1. Installiere alle nötigen dependencies
    
* Hier der Befehl zum installieren von Babel:
    - npm install -D babel-loader @babel/core @babel/preset-env webpack

2. Bearbeite die Config Datei so das der babel-loader angewendet wird. 
    - loader: 'babel-loader'
    - presets: ['@babel/preset-env']

3. Wandle die scr/app.js mit webpack um