# To-Do

1. Schreibe webpack.config.js so um, das es zwei entry points gibt und bundle diese. 