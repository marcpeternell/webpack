# To-Do

1. generiere für die zwei entry points einen hash