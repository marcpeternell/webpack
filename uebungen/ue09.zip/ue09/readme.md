# To-Do

1. installiere das plugin: mini-css-extract-plugin

2. schreibe die config Datei so um das das soeben installierte Plugin verwendet wird (MiniCssExtractPlugin.loader) und die gebündelte Datei den Namen app.css hat
    - filename: 'app.css'

3. Bundle die Dateien und untersuche den Public Ordner