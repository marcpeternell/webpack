# To-Do

1. installiere den sass-loader und den node-sass

2. schreibe die webpack config so um das statt css, scss verwendet wird und füge den sass-loader hinzu

3. Bundle die Dateien und untersuche den Public Ordner