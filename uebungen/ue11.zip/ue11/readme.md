# To-Do

1. schreibe die config datei so um das das bild nicht inline eingebunden wird.